// 參考 http://goo.gl/VZjxMk，http://goo.gl/RTj4wY
$(function() {
	$("#myfile").on("change", function() {
		var formData = new FormData();
		var file = $('#myfile')[0].files[0];
		formData.append('file', file);
		if(file!=undefined) {
			$.ajax({
				url : './UploadFile',
				type : "POST",
				data : formData,
				dataType : 'text',	
				
				//必須false，才會自動加上正確的Content-Type   
				//取得jQuery XMLHttpRequest物件，增加 progress事件綁定，返回給ajax使用
				processData : false,
				contentType : false,
				xhr : function() {
					var xhr = $.ajaxSettings.xhr();
					if (onprogress && xhr.upload) {
						xhr.upload.addEventListener("progress" , onprogress, false);
						return xhr;
					}
				},
				beforeSend : function() {
					$('#uploadStat').empty();
					$('#uploadProgress').val(0);
				},
				success : function(backData) {
					var jobj = JSON.parse(backData);
					if(jobj.stat=='success') {
						$('#uploadStat').val(jobj.msg);
					} else {
						$('#uploadStat').val(jobj.msg);
					}
				},
				error : function(xhr, ajaxOpt, errorMsg) {
					$('#uploadStat').html('upload error !');
				},
			});		
		}
	});
});

function onprogress(evt){
	var tot = evt.total;					// 檔案總大小
	var loaded = evt.loaded;				// 已經上傳大小
	var per = Math.floor(100*loaded/tot);	// 計算百分比
	$('#uploadStat').html(per + '%');
	$('#uploadProgress').animate({ value: per }, 150);
}
